#ifndef _DEBUG_MEMORY_H
#define _DEBUG_MEMORY_H

//#define SFML_ONBOARD

#define BUG_OFF

//#define DEBUG_MEMORY

#define XALLOC

#ifdef DEBUG_MEMORY
#define XALLOC
#endif // DEBUG_MEMORY

#endif

